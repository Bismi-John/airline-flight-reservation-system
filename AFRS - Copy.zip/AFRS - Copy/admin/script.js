function airport() {
    let airport = document.getElementById("air").value;
}
if (x == "") {
    alert("name field is empty");
    return false;
}
