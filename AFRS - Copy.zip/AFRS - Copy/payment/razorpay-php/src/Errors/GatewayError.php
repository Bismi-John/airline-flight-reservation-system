<?php

namespace Razorpay\Api\Errors;

class GatewayError extends Error
{
}