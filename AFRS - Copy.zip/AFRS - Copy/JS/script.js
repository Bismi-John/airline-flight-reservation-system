// Author: Bismi John
// var string = " Online Flight Booking";
// var str = string.split("");
// var el = document.getElementById("str");
// (function animate() {
//     str.length > 0 ? (el.innerHTML += str.shift()) : clearTimeout(running);
//     var running = setTimeout(animate, 90);
// })();
let count = 1;
$("#passenger2").hide();
$("#passenger3").hide();
function addPassenger() {
    if (count < 3) count++; // Increment passenger count by 1
    document.getElementById("passengerCount").innerHTML = count;
}

function subtractpassenger() {
    if (count > 1) {
        count--; // decrement passenger count by 1
        document.getElementById("passengerCount").innerHTML = count;
    }
}

$(document).ready(() => {
    count = 1;

    $("#plus").click(() => {
        if (count == 2) {
            $("#passenger2").show(2000);
        }
        if (count == 3) {
            $("#passenger3").show(2000);
        }
    });

    $("#minus").click(() => {
        if (count == 1) {
            $("#passenger2").hide(2000);
            // $("#passenger3").hide(2000);
        }
        if (count == 2) {
            $("#passenger3").hide(2000);
        }
    });
});
