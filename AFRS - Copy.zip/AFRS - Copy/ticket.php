<?php
    require 'connection.php';
   ?>
<?php
   $name=$_SESSION['name'];

   ?>
<?php
    require 'header.php';
    ?>  

<div class="container-fluid ">
     <div class=" row justify-content-center p-lg-5 my-lg-5 p-0 m-0">
       <div class=" row  w-100 justify-content-center ">
            <div class="row w-75 border border-primary p-lg-5 p-0 bgimage  rounded-5">
                   
                   <table>
                        <thead>
                            <td >NAME</td>
                            <td>FLIGHT</td>
                            <td>DATE</td>
                            <td>SEAT</td>
                            <td>CLASS</td>
                        </thead>
                        <tbody>
                            <th><?php echo $name; ?></th>
                            <th>from db</th>
                            <th>from db</th>
                            <th>from db</th>
                            <th>from db</th>
                        </tbody>
                    </table>
                   
            <div class="row justify-content-around m-0 px-lg-5 pt-lg-3 p-0 m-0">
                <p class="col-sm-3 col-12 fonte">kochin from db</p>
                <img src="image/edited.png" alt="" class="img-fluid image1 col-sm-3 col-12">
                <p class="col-sm-3 col-12 fonte">tvm from db</p>

            </div>
            <p class="text-center text-danger">GATE CLOSES 40MIN BEFORE DEPARTURE</p>
         </div>
          
       </div>
       <div class="text-end">
    <button class="btn btn-success">DOWNLOAD</button>
</div> 
     </div> 
    
</div>


<?php
require 'footer.php';
?>